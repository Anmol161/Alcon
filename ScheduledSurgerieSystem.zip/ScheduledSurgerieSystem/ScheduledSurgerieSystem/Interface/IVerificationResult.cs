﻿using ScheduledSurgerieSystem.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduledSurgerieSystem.Interface
{
    public interface IVerificationResult
    {
        public ValidationResult VerifyData(string filePath);
        public bool IsValid(int surgeyIndex);
    }
}
