﻿using Newtonsoft.Json;
using ScheduledSurgerieSystem.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduledSurgerieSystem.Controller
{
    public class PatientReadFromFile
    {
        private readonly string _fileName;
        public PatientReadFromFile(string fileName)
        {
            _fileName=fileName;
        }

        public List<Patient> GetPatientData()
        {
            using StreamReader reader = new(_fileName);
            var json= reader.ReadToEnd();
            var patientData = JsonConvert.DeserializeObject<List<Patient>>(json);
            return patientData;
        }
    }
}
