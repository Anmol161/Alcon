﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduledSurgerieSystem.Controller
{
    public class ValidationResult
    {
        public bool Success { get; set; }
        public List<String> ErrorMessage { get; set; }
        public ValidationResult()
        {
            Success = true;
            ErrorMessage = new List<String>();
        }
    }
}
