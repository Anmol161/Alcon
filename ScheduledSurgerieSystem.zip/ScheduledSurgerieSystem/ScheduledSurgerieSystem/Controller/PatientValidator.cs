﻿using Newtonsoft.Json;
using ScheduledSurgerieSystem.Enum;
using ScheduledSurgerieSystem.Interface;
using ScheduledSurgerieSystem.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScheduledSurgerieSystem.Controller
{
    public class PatientValidator : IVerificationResult
    {
        private readonly string _filePath;
        public PatientValidator(string filePath)
        {
            _filePath=filePath;
        }
        public bool IsValid(int surgeyIndex)
        {
            try
            {
                using StreamReader reader = new StreamReader(_filePath);
                var json = reader.ReadToEnd();
                var surgery = JsonConvert.DeserializeObject<List<Patient>>(json);
                if (surgeyIndex > surgery.Count() || surgeyIndex < 0)
                {
                    Console.WriteLine($"input index is not valid, please enter in between 0 to {surgery.Count()}");
                    return false;
                }
                var verify = surgery[surgeyIndex];
                var dateFormatSurgery = DateTime.TryParseExact(verify.DateOfSurgery, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date);
                var dateFormateDOB = DateTime.TryParseExact(verify.DateOfSurgery, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dateDOB);
                if (verify == null)
                {
                    return false;
                }
                if (!dateFormateDOB)
                {
                    return false;

                }
                if (!dateFormatSurgery)
                {
                    return false;
                }
                if (date < DateTime.Today)
                {
                    return false;
                }
                var jsonserealize = JsonConvert.SerializeObject(verify);
                Console.WriteLine(jsonserealize);
                Console.ReadLine();
                return true;
            }
            catch (JsonException ex)
            {
                Console.WriteLine("An Error occure while Desealized the objec"+ ex.Message);
                return false;
            }
            catch(Exception ex)
            {
                Console.WriteLine("An error Occured"+ex.Message);
                return false;
            }
        }

        public ValidationResult VerifyData(string filePath)
        {
            ValidationResult validationResult = new ValidationResult();
            try
            {
                
                using StreamReader reader = new StreamReader(filePath);
                var json = reader.ReadToEnd();
                var surgery = JsonConvert.DeserializeObject<List<Patient>>(json);
                //check for the json Data
                if (surgery == null || surgery.Count == 0)
                {
                    validationResult.Success = false;
                    validationResult.ErrorMessage.Add("No Record Found");
                    return validationResult;
                }

                // check for age and date of birth formate

                foreach (var patientDateofBirth in surgery)
                {
                    var surgeryDate = DateTime.TryParseExact(patientDateofBirth.DateOfBirth, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date);
                    int age = DateTime.Today.Year - date.Year;
                    if (age > 90 || age < 1)
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add($"age is not suitable for the surgery for patient id{patientDateofBirth.PatientId}");
                    }
                    if (!surgeryDate)
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add($"Date is not in valid format for patient id{patientDateofBirth.PatientId}");
                    }
                }

                //"Date of Surgery" Validation and Date Formate Validation

                foreach (var PatientSurgeryDate in surgery)
                {
                    var surgeryDate = DateTime.TryParseExact(PatientSurgeryDate.DateOfSurgery, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime date);
                    if (!surgeryDate)
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add($"Date is not in valid format for patient id{PatientSurgeryDate.PatientId}");
                    }
                    var todayDate = DateTime.Today;
                    if (date < DateTime.Today)
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add($"Sugery Date Can't be in past for patient ID : {PatientSurgeryDate.PatientId}");
                    }
                }

                //check for all record is filled or not
                foreach (var patientSurgery in surgery)
                {
                    if (string.IsNullOrEmpty(patientSurgery.PatientId.ToString()) || string.IsNullOrEmpty(patientSurgery.DateOfSurgery) ||
                        string.IsNullOrEmpty(patientSurgery.DateOfBirth) || string.IsNullOrEmpty(patientSurgery.SurgeryType.ToString()))
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add("All field should be fill");
                    }
                }
                //check if the same patient id having different DOB 
                var patientRecord = surgery.GroupBy(s => s.PatientId);
                foreach (var group in patientRecord)
                {
                    if (group.Select(x => x.DateOfBirth).Distinct().Count() > 1)
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add($"Record for Patient id{group.Key} have diiferent date of Birth");
                    }
                }

                //check for the Type of Surgery

                foreach (var patientSurgeryType in surgery)
                {
                    if (patientSurgeryType.SurgeryType.Equals("left") && patientSurgeryType.SurgeryType.Equals("right"))
                    {
                        validationResult.Success = false;
                        validationResult.ErrorMessage.Add("Invalidate Surgery Type");
                    }
                }

                return validationResult;
            }
            catch (JsonException ex)
            {
                Console.WriteLine("An error message occure while Deserialize Object" + ex.Message);
                return validationResult;
            }
            catch(Exception ex)
            {
                Console.WriteLine("An error Occured" + ex.Message);
                return validationResult;
            }
        }
    }
}
