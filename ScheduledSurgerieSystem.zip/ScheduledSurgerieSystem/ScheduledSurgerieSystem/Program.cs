﻿// See https://aka.ms/new-console-template for more information
using ScheduledSurgerieSystem.Controller;
using ScheduledSurgerieSystem.Interface;

IVerificationResult verificationResult = new PatientValidator("PatientJsonData.json");
// console statement
Console.WriteLine("Please Enter index to validate Data");
//Read data from user
int indexnumber=Convert.ToInt32(Console.ReadLine());

var IsValid=verificationResult.IsValid(indexnumber);
// result for the Validation
Console.WriteLine("Validation for the input index is "+ IsValid);
Console.ReadLine();

//verify all the Data
var result = verificationResult.VerifyData("PatientJsonData.json");
if (result.Success == true)
{
    Console.WriteLine($"{result.Success} All the Data present in Json File is Valid");
    Console.ReadLine();
}
else
{
    Console.WriteLine(result.Success);
    for (int i = 0; i < result.ErrorMessage.Count(); i++)
    {
        Console.WriteLine(result.ErrorMessage[i]);
    }
    Console.ReadLine();
}