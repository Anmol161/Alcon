﻿using iTunes.Models;
using iTunes.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace iTunes.ViewModel
{
    public class SongsVM :INotifyPropertyChanged
    {
        public ObservableCollection<Songs> Songs { get; set; }
        public ObservableCollection<Songs> PlayListSongs { get; }=new ObservableCollection<Songs>();
        public ICommand ShortByName { get; set; }
        public ICommand AddToPlayList { get; set; }

        private Songs _selectedSong;

       

        public Songs SelectedSong
        {
            get { return _selectedSong; }
            set
            {
                _selectedSong = value;
                OnPropertyChanged(nameof(value));
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        
        public SongsVM()
        {
            Songs= SongsCollection.GetSongs();
            ShortByName = new RelayCommand(ExecuteCommand);
            AddToPlayList=new RelayCommand(AddToPlayList1);
        }

        private void ExecuteCommand(object obj)
        {
            Songs = new ObservableCollection<Songs>(Songs.OrderBy(x => x.Title));
            
        }
        private void AddToPlayList1(object parameter)
        {
            PlayListSongs.Add(SelectedSong);
            SongsCollection.GetSongs();
        }
    }
}
