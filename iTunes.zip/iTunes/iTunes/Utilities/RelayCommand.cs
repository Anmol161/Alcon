﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace iTunes.Utilities
{
    class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Func<object, bool> _canExecute;
       // private readonly Predicate<object> _canExecute;
        private Action<object> songs;

        public event EventHandler? CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove {  CommandManager.RequerySuggested -= value;}
        }

        public RelayCommand(Action<object> execute, Func<object, bool> canExecute=null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        //public RelayCommand(Action<object> songs)
        //{
        //    this.songs = songs;
        //}

        //public bool CanExecute(object? parameter)=>_canExecute==null || _canExecute(parameter);
        public bool CanExecute(object? parameter)
        {
            return true;
        }
        

        public void Execute(object? parameter)
        {
            _execute(parameter);
        }
    }
}
